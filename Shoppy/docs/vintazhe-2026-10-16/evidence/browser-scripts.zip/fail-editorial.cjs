const original=globalThis.fetch;
globalThis.fetch=(input,init)=>{const url=typeof input==='string'?input:input?.url??String(input);if(url.includes('.supabase.co/rest/v1/home_sections'))return Promise.resolve(new Response(JSON.stringify({message:'Simulated initial editorial outage'}),{status:503,headers:{'content-type':'application/json'}}));return original(input,init)};
