#!/bin/sh
export PATH=/home/leandro/.nvm/versions/node/v24.21.0/bin:/usr/bin:/bin
export CHROME_PATH=/opt/google/chrome/chrome
for page in home catalogo; do
 case "$page" in home) route=/;; catalogo) route=/catalogo;; esac
 for run in 1 2 3; do
  node /home/leandro/.npm/_npx/0f94ee7615faf582/node_modules/lighthouse/cli/index.js "http://localhost:3001$route" --only-categories=performance --chrome-flags='--headless --no-sandbox --disable-dev-shm-usage' --output=json --output-path="/tmp/vinta-implementation/lighthouse-$page-$run.json" --save-assets --quiet > "/tmp/vinta-implementation/lighthouse-$page-$run.log" 2>&1 || exit 1
  echo "Lighthouse $page $run complete"
 done
done
