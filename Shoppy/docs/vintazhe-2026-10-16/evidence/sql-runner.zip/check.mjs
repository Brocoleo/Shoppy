import { PGlite } from '@electric-sql/pglite';
import { pg_trgm } from '@electric-sql/pglite/contrib/pg_trgm';
import { readFile } from 'node:fs/promises';
const root='/home/leandro/Documentos/ChatGPT/React Native/Shoppy';
const notices=[];
const db=new PGlite({extensions:{pg_trgm},onNotice:n=>{notices.push(n.message); console.log(n.message)}});
try {
 for(const file of ['supabase/tests/setup_local.sql','supabase/migrations/20260928000000_init_schema.sql','supabase/migrations/20260928000001_rls_policies.sql','supabase/migrations/20261016161216_admin_images_vinta_20261016.sql','supabase/migrations/20261016161216_admin_images_vinta_20261016.sql','supabase/tests/admin_images_tests.sql']) {
  await db.exec(await readFile(`${root}/${file}`,'utf8'));
  console.log(`OK ${file}`);
 }
 const remains=await db.query("select count(*)::int n from auth.users where email like 'images-%@example.test'");
 if(remains.rows[0].n!==0) throw Error('Fixture rollback failed');
 console.log(JSON.stringify({passed:true,notices,fixtureRollback:true}));
} finally {await db.close()}
