import { PGlite } from '@electric-sql/pglite';
import { pg_trgm } from '@electric-sql/pglite/contrib/pg_trgm';
import { readFile } from 'node:fs/promises';
const root='/home/leandro/Documentos/ChatGPT/React Native/Shoppy';
const migration=await readFile(`${root}/supabase/migrations/20261016161216_admin_images_vinta_20261016.sql`,'utf8');
const fixture=await readFile(`${root}/supabase/tests/admin_images_tests.sql`,'utf8');
async function base(){const db=new PGlite({extensions:{pg_trgm}});for(const file of ['supabase/tests/setup_local.sql','supabase/migrations/20260928000000_init_schema.sql','supabase/migrations/20260928000001_rls_policies.sql']) await db.exec(await readFile(`${root}/${file}`,'utf8'));return db;}
{
 const db=await base();try {
  await db.exec(await readFile(`${root}/supabase/migrations/20261010000001_beta_cart_images.sql`,'utf8'));
  await db.exec(migration); await db.exec(migration); await db.exec(fixture);
  console.log('PASS: prior beta image objects replaced, migration repeatable, security tests pass');
 }finally{await db.close()}
}
{
 const db=await base();try {
  await db.exec(`drop index public.product_images_single_cover_uidx; insert into public.products(id,slug,name,price_clp,stock) values ('e1610000-0000-4000-8000-000000000011','duplicate-cover-check','Test',1000,1); insert into public.product_images(product_id,storage_path,is_cover) values ('e1610000-0000-4000-8000-000000000011','test/a.webp',true),('e1610000-0000-4000-8000-000000000011','test/b.webp',true);`);
  let refused=false;try{await db.exec(migration)}catch(e){if(!e.message.includes('DUPLICATE_PRODUCT_COVERS'))throw e;refused=true;await db.exec('rollback')}
  if(!refused)throw Error('Migration accepted invalid pre-existing covers');
  const result=await db.query(`select count(*)::int n from public.product_images where is_cover`);
  if(result.rows[0].n!==2)throw Error('Migration mutated existing cover data');
  console.log('PASS: duplicate pre-existing covers block migration without silently modifying data');
 }finally{await db.close()}
}
